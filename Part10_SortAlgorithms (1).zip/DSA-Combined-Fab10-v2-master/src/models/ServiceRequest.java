package models;

/**
 * Placeholder / reference model for a single service request record.
 *
 * NOTE: If the project already has a ServiceRequest class (it likely does,
 * since ResourceOptimizer, UrgentDispatcher and AuditLogSorter already
 * operate on service requests), DELETE this file and do not add it to the
 * repo. This class exists only so that SortAlgorithms.java has something
 * concrete to compile and demo against if no such model is on hand yet.
 *
 * Fields follow the same style as the existing models package: private
 * fields, empty constructor, full constructor, getters, setters, toString.
 */
public class ServiceRequest {

    private int requestId;
    private long timeSubmitted; // epoch millis, or any sortable long timestamp
    private int urgency;        // higher value = more urgent

    public ServiceRequest() {
    }

    public ServiceRequest(int requestId, long timeSubmitted, int urgency) {
        this.requestId = requestId;
        this.timeSubmitted = timeSubmitted;
        this.urgency = urgency;
    }

    public int getRequestId() {
        return requestId;
    }

    public void setRequestId(int requestId) {
        this.requestId = requestId;
    }

    public long getTimeSubmitted() {
        return timeSubmitted;
    }

    public void setTimeSubmitted(long timeSubmitted) {
        this.timeSubmitted = timeSubmitted;
    }

    public int getUrgency() {
        return urgency;
    }

    public void setUrgency(int urgency) {
        this.urgency = urgency;
    }

    @Override
    public String toString() {
        return "ServiceRequest{" +
                "requestId=" + requestId +
                ", timeSubmitted=" + timeSubmitted +
                ", urgency=" + urgency +
                '}';
    }
}
